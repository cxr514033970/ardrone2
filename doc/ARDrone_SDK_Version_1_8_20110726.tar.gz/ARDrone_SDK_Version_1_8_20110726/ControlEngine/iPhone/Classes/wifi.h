/*
 *  wifi.h
 *  ARDroneEngine
 *
 *  Created by f.dhaeyer on 30/03/11.
 *  Copyright 2011 Parrot SA. All rights reserved.
 *
 */
#ifndef _WIFI_H_
#define _WIFI_H_

extern char iphone_mac_address[];

void get_iphone_mac_address(const char *itfName);

#endif // _WIFI_H_
