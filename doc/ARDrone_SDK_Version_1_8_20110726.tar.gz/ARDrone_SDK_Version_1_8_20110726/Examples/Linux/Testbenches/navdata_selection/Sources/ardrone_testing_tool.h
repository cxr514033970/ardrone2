#ifndef _MYKONOS_TESTING_TOOL_H_
#define _MYKONOS_TESTING_TOOL_H_

#include <stdio.h>
#include <VP_Os/vp_os_types.h>

C_RESULT signal_exit();

#endif // _MYKONOS_TESTING_TOOL_H_
