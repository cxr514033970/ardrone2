#include <config.h>
#include <ardrone_api.h>
#include <UI/ui.h>
/*
C_RESULT custom_reset_user_input(input_state_t* input_state, uint32_t user_input )
{
  return C_OK;
}

C_RESULT custom_update_user_input(input_state_t* input_state, uint32_t user_input )
{

  return C_OK;
}
*/
