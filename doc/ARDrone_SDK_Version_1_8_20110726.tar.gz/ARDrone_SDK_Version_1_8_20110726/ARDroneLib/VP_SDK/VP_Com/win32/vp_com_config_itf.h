#ifndef _COMIP_H_
#define _COMIP_H_

int vp_com_config_itf( 
					  const char* _interface, 
					  const char * _ip, 
					  const char* _broadcast, 
					  const char* _netmask );

#endif // _COMIP_H_
