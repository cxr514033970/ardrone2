#include <VP_Os/vp_os_types.h>

// Default zigzag ordering matrix
extern int32_t video_zztable_t41[16];

void zagzig_4x4 (int16_t * in, int16_t * out);
